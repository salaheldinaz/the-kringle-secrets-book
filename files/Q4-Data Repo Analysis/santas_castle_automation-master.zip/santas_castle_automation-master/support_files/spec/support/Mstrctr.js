
module.export.addNote = function () {
      console.log('Secret Key');
      return 'wPu4Ry8FBhckXWjCfjx5QlkRR8vcAqLBf6sgmrcjwFv0c1xjMUw1Qh+rWVQZTTRP';
 };
