Executive machine learning function will go here. Hoping our elf hacker friends can help with this.
