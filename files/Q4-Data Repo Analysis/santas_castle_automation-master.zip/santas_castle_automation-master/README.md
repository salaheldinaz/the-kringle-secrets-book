## Santa's Castle and drone fleet automation

<img src="https://img.shields.io/badge/completion-95%25-red.svg?style=plastic">&nbsp;<img src="https://img.shields.io/crates/dv/rustc-serialize.svg?style=plastic">



<img src="Drone.png">

## Vision

Upgrade Santa's Castle with automation to include a new fleet of drones capable of autonomously delivering presents 90% faster than conventional methods.

The aim of this project is to improve efficiency and sustainment of Santa's Castle and Christmas present delivery.

We’re solving the problem of sustaining Christmas operations at Santa's Castle while delivering presents on time around the world.


## History

Our lead elf data science engineers Bushy Evergreen and Shinny Upatree started this project early last year internally. This project continues to consume our limited resources at the North Pole
prompting our elves to discover new innovations by outsourcing.

Our workshop open-sourced this project because we need elf hacker contributors like you to help establish AI and Machine Learning in our systems at Santa's Castle.

## Message from Shinny

We all get what we git, then we git what we've got.
When we're full of old pulls, then we're holding a lot.
Do you wonder what happens to things that we thought,
Were too private then trampled with things that were not?

I assume that our secrets are gone from the cloud.
They still sit here in local reposit'ries' shroud,
But I heard that old Redberry was rather wowed,
When she found out her keys were exposed - wasn't proud.

So when I found that I had thown creds with a push,
Pretty sure I did stomp them with clean files - smoosh!
If you find an old password 'neath folder or bush,
Would you kindly play nice and say nothing - just shush?"


## Installation


To install, you will have to run these commands to setup the project:

<img src="install.gif">

Enjoy!

## Contributing

We’re really happy to accept contributions from the community, that’s the main reason why we open-sourced it! There are many ways to contribute, even if you’re not a technical elf.

We’re using the infamous [simplified Gitlab workflow](https://about.gitlab.com/2016/10/25/gitlab-workflow-an-overview/) to accept modifications (even internally), basically you’ll have to:

* create an issue related to the problem you want to fix (good for traceability and cross-reference)
* fork the repository
* create a branch (optionally with the reference to the issue in the name)
* hack hack hack
* commit incrementally with readable and detailed commit messages
* submit a pull-request against the master branch of this repository

Our workshop will take care of tagging your issue with the appropriated labels and answer within a week (hopefully less!) to the problem you encounter.

If you’re not familiar with open-source workflows or our set of technologies, do not hesitate to ask for help! Our elves can mentor you or propose good first bugs (as labeled in our issues).

### Submitting bugs

You can report issues directly on Gitlab, that would be a really useful contribution given that we lack some user testing on the project. Please document as much as possible the steps to reproduce your problem (even better with screenshots).


### Adding documentation

Our elves are doing their best to document each usage of the project but you can improve it or add you own sections. The documentation is available within the /assets/ folder. You don’t have to build anything, we’ll take care of it once your changes are merged.

### Hacking backend

Hello fellow elf hacker, it’s good to have you on board! There is an extra step to install development dependencies if you plan to modify our core server:

```shell
pepper ministix install -r requirements/
bower install
fab runserver
```

Note that each feature will be discussed and developed in the open with the whole community.


## License

We’re using the <img src="https://img.shields.io/badge/license-KRINGLECON-red.svg"> because we believe in outsourcing to smart hacker elves like you!!!


<img src="https://img.shields.io/twitter/url/https://twitter.com/kringlecon/shields.io.svg?style=social">


