Can an elf get a configuration file for faster editing? Also, we need to automate core drone delivery functions. This config file is a great place for hacker elves to start contributing! 
